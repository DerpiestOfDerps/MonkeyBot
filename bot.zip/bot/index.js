const Discord = require('discord.js');
const client = new Discord.Client();
const { prefix, token } = require('./config.json');
const broadcast = client.voice.createBroadcast


client.once('ready', () =>{
    console.log('Ready!');
})
client.login(token);

client.on('message' message =>{
    if(message.content === `${prefix}info`){
        message.reply ('I am Monkey Bot. I was created by Mega#3139. Please message him for inquiries.')
    }   elseif(msg.content === `${prefix}serverinfo`){
        message.reply (`This server's name is: ${message.guild.name}\nMember Count: ${message.guild.MemberCount}`);
    }elseif(message.content === `${prefix}age`){
        message.reply(`Monkey Bot was created on: May 24th, 2021.\nThis server was created on: ${message.guild.createdAt}`);
    }
}); 
client.on('message', async message => {
    if (!message.guild) return;
  
    if (message.content === '/join') {
      
      if (message.member.voice.channel) {
        const connection = await message.member.voice.channel.join();
      } else {
        message.reply('You need to join a voice channel first!');
      }
    }
  });
client.on('message', message => {
	if (message.content === `${prefix}play`){
    if (!message.content.startsWith(prefix) || message.author.bot) return;
	const args = message.content.slice(prefix.length).trim().split(' ');
	connection.play(fs.createReadStream(args), {
        type: 'webm/opus',
      });
    }
});
        