const Discord = require('discord.js');
const client = new Discord.Client();
const { prefix, token } = require('./config.json');
const broadcast = client.voice.createBroadcast


client.once('ready', () =>{
    console.log('Ready!');
})
client.login(token);

client.on('message' msg =>{
    if(msg.content === `${prefix}info`){
        msg.reply ('I am Monkey Bot. I was created by Mega#3139. Please message him for inquiries.')
    }   elseif(msg.content === `${prefix}serverinfo`){
        msg.reply (`This server's name is: ${message.guild.name}\nMember Count: ${message.guild.MemberCount}`);
    }elseif(msg.content === `${prefix}age`){
        msg.reply(`Monkey Bot was created on: May 24th, 2021.n\This server was created on: ${message.guild.createdAt}`);
    }
}); 

client.on('message', message => {
	if (msg.content === `${prefix}play`){
        const url = 
        broadcast.play(url);
    }
});
        